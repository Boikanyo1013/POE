package com.mycompany.prog5121_fa1;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;

public class Message {
    private String messageId;
    private String recipient;
    private String content;
    private int count;
    private static int totalSent = 0;
    private static List<String> sentMessages = new ArrayList<>();
    
    public static ArrayList<String> disregardedMessages = new ArrayList<>();
    public static ArrayList<String> storedMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();
    public static ArrayList<String> storedRecipients = new ArrayList<>();
    public static ArrayList<String> storedSenders = new ArrayList<>();
    public static ArrayList<String> sentRecipients = new ArrayList<>();
    

    public Message(String recipient, String content, int count) {
        this.recipient = recipient;
        this.content = content;
        this.count = count;
        this.messageId = generateMessageId();
    }

    public Message() {
        this.messageId = generateMessageId();
    }

    private String generateMessageId() {
        Random rand = new Random();
        int number = rand.nextInt(100000000);
        return String.format("00%08d", number);
    }

    public String getMessageId() {
        return messageId;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
    }

    public String checkMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    public String checkRecipientCell(String number) {
        if (number != null && number.startsWith("+") && number.length() <= 13) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    public String createMessageHash() {
        String[] words = content.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^A-Za-z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        String firstTwo = messageId.substring(0, 2);
        return firstTwo + ":" + count + ":" + (firstWord + lastWord).toUpperCase();
    }

    public String MessageIDGenerated() {
        return "Message ID generated: " + messageId;
    }

        public String SentMessage(int choice) {
        if (choice == 1) {
            totalSent++;
            String hash = createMessageHash();
            sentMessages.add(content);
            messageHashes.add(hash);
            messageIDs.add(messageId);
            sentRecipients.add(recipient);
            storeMessage();
            return "Message successfully sent.";
        } else if (choice == 2) {
            disregardedMessages.add(content);
            messageHashes.add(createMessageHash());
            messageIDs.add(messageId);
            return "Press 0 to delete the message.";
        } else {
            storedMessages.add(content);
            storedRecipients.add(recipient);
            storedSenders.add("Developer");
            messageHashes.add(createMessageHash());
            messageIDs.add(messageId);
            storeMessage();
            return "Message successfully stored.";
        }
    }
        
            public static String displaySentMessages() {
        String out = "";
        for (int i = 0; i < sentRecipients.size(); i++) {
            out += "Recipient: " + sentRecipients.get(i) + ", Hash: " + messageHashes.get(i) + "\n";
        }
        return out.isEmpty() ? "No sent messages." : out;
    }

    public static String displayDisregarded() {
        return disregardedMessages.isEmpty() ? "No disregarded messages." : String.join("\n", disregardedMessages);
    }

    public static String displayStored() {
        String out = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            out += storedSenders.get(i) + " -> " + storedRecipients.get(i) + ": " + storedMessages.get(i) + "\n";
        }
        return out.isEmpty() ? "No stored messages." : out;
    }

    public static String displayLongest() {
        if (storedMessages.isEmpty() && sentRecipients.isEmpty()) return "No messages.";
        String longest = storedMessages.isEmpty() ? "" : sentMessages.get(0);
        for (String m : sentMessages) if (m.length() > longest.length()) longest = m;
        return "Longest: " + longest;
    }

    public static String searchByID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) return "Found: " + sentMessages.get(i) + " to " + sentRecipients.get(i);
        }
        return "ID not found.";
    }

    public static String searchByRecipient(String rec) {
        String out = "";
        for (int i = 0; i < sentRecipients.size(); i++) {
            if (sentRecipients.get(i).equals(rec)) out += sentMessages.get(i) + "\n";
        }
        return out.isEmpty() ? "No messages for that recipient." : out;
    }

    public static String deleteByHash(String hash) {
        int idx = messageHashes.indexOf(hash);
        if (idx >= 0) {
            messageHashes.remove(idx);
            messageIDs.remove(idx);
            sentMessages.remove(idx);
            sentRecipients.remove(idx);
            return "Message successfully deleted.";
        }
        return "Hash not found.";
    }

    public String printMessages() {
        String result = "";
        for (String msg : sentMessages) {
            result += msg + "\n";
        }
        return result;
    }

    public int returnTotalMessagess() {
        return totalSent;
    }

    public void storeMessage() {
        try {
            FileWriter writer = new FileWriter("messages.json", true);
            writer.write("{\"messageId\":\"" + messageId + "\",\"recipient\":\"" + recipient + "\",\"message\":\"" + content + "\",\"hash\":\"" + createMessageHash() + "\"}\n");
            writer.close();
        } catch (IOException e) {
        }
    }
}